import { LightningElement, api, track } from 'lwc';
import getAcc from '@salesforce/apex/AccountGet.getAccounts';
const DELAY=100;
var textFilter;
export default class LwcDemo2 extends LightningElement {
@track error;
@track myAcc;
@track accName='';
@track filtrText='';
@track noOfRecord=0;


namehandler(event){    
this.accName=event.target.value;    
}
recordLimitHandler(event){  
this.noOfRecord=event.target.value;        
}
searchHandler(){
//console.log('Inside handler');
window.clearTimeout(this.delayTimeout);   
// eslint-disable-next-line @lwc/lwc/no-async-operation
this.delayTimeout = setTimeout(() => {
    getAcc({ accN : this.accName,noOfRec: this.noOfRecord})
        .then((result) => { 
            this.myAcc = [...result];                           
            this.error = undefined;
        })
        .catch((error) => {
            this.error = error;
            this.myAcc = undefined;
        });
}, DELAY);}
filterTextHandler(event){
this.filtrText=event.target.value;   
textFilter=this.filtrText;    
}
 filterHandler(){          
    this.myAcc=this.myAcc.filter(function(myRes){
return myRes.Name === textFilter;
});
}
}