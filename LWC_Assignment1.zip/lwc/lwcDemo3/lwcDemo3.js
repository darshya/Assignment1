import { LightningElement,api } from 'lwc';

export default class LwcDemo3 extends LightningElement {
@api nameAccount='';

}